import 'package:flutter/material.dart';


import '../../data/model/model_contacts.dart';

class InfoPage extends StatefulWidget {
  final ModelContacts data;
  const InfoPage({super.key,required this.data});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Kontakte",style: TextStyle(color: Colors.black),),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: () {
                
              }, icon: Image.asset("assets/Vector.jpg"))
        ],
        iconTheme: const IconThemeData(color: Colors.black,size: 30),
      )
    );
  }
}