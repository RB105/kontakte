class UrlsProject {
  static const String myAPI="https://jsonplaceholder.typicode.com/users";
}