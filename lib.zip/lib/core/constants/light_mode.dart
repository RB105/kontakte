import 'package:flutter/material.dart';

class LightMode {
  static Color scaffoldColor = Colors.white;
}