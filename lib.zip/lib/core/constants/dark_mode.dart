import 'package:flutter/widgets.dart';

class DarkMode {
  static Color scaffoldColor = const Color(0xff262345);
}