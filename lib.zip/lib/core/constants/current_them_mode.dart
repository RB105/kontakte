import 'dart:ui';

import 'light_mode.dart';

class CurrentThemMode {
  static Color scaffoldColor = LightMode.scaffoldColor;
}